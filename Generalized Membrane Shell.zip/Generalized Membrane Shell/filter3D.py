from paraview import vtk
import math
R=0.5
pdi = self.GetUnstructuredGridInput()
pdo = self.GetOutput()
newPoints = vtk.vtkPoints()
numPoints = pdi.GetNumberOfPoints()
for i in range(0, numPoints):
    coord = pdi.GetPoint(i)
    x, y, z = coord[:3]
    s = (R+z)*math.cos(x)
    t = (R+z)*math.sin(x)
    u = y
    newPoints.InsertPoint(i, s, t, u)
pdo.SetPoints(newPoints)
