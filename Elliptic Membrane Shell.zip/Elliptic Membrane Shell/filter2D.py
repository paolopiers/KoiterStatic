from paraview import vtk
import math
R1=1.0
R2=1.0
R3=1.0
pdi = self.GetUnstructuredGridInput()
pdo = self.GetOutput()
newPoints = vtk.vtkPoints()
numPoints = pdi.GetNumberOfPoints()
for i in range(0,numPoints):
    coord = pdi.GetPoint(i)
    x, y, z = coord[:3]
    s = R1*math.cos(x)*math.cos(y)
    t = R2*math.cos(x)*math.sin(y)
    z = R3*math.sin(x)
    newPoints.InsertPoint(i, s, t, z)
pdo.SetPoints(newPoints)