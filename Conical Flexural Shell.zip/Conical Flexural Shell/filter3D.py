from paraview import vtk
import math
R=0.2
pdi = self.GetUnstructuredGridInput()
pdo = self.GetOutput()
newPoints = vtk.vtkPoints()
numPoints = pdi.GetNumberOfPoints()
for i in range(0, numPoints):
    coord = pdi.GetPoint(i)
    x, y, z = coord[:3]
    s = (R+z)*y*math.cos(x)
    t = (R+z)*y*math.sin(x)
    u = (0.4+z)*y
    newPoints.InsertPoint(i, s, t, u)
pdo.SetPoints(newPoints)
